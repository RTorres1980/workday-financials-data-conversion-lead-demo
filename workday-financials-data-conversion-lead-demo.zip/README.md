# Workday Financials Data Conversion Lead Demo

## Overview
This project simulates the end-to-end data conversion process for a Workday Financials implementation — including data extraction, transformation, validation, and reporting.

## How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run scripts:
   ```bash
   python scripts/extract_data.py
   python scripts/transform_data.py
   python scripts/validate_data.py
   python scripts/generate_summary_report.py
   ```

Outputs will appear in the `data/transformed` and `reports` folders.
