import pandas as pd

def generate_summary():
    gl = pd.read_csv("data/transformed/workday_gl_workbook.csv")
    summary = gl.groupby("Workday_Account")["Balance"].sum().reset_index()
    summary.to_csv("reports/conversion_summary_report.csv", index=False)
    print("Conversion summary report generated successfully.")

if __name__ == "__main__":
    generate_summary()
