import pandas as pd

def validate_data():
    data = pd.read_csv("data/transformed/workday_gl_workbook.csv")
    issues = data[data["Balance"].isna()]
    print(f"Validation: {len(issues)} missing balances found.")
    issues.to_csv("reports/validation_issues.csv", index=False)

if __name__ == "__main__":
    validate_data()
