import pandas as pd
from pathlib import Path

def extract_data():
    data_dir = Path("data/legacy")
    print("Extracting legacy data...")

    netsuite_gl = pd.read_csv(data_dir / "netsuite_gl.csv")
    concur_suppliers = pd.read_csv(data_dir / "concur_suppliers.csv")

    print(f"Loaded {len(netsuite_gl)} GL records and {len(concur_suppliers)} supplier records.")
    return netsuite_gl, concur_suppliers

if __name__ == "__main__":
    extract_data()
