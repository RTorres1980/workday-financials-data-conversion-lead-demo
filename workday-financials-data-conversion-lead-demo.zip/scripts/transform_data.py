import pandas as pd
from pathlib import Path

def transform_gl_data():
    gl = pd.read_csv("data/legacy/netsuite_gl.csv")

    gl["Workday_Account"] = gl["Account_Number"].apply(lambda x: f"WD-{x}")
    gl["Balance"] = gl["Debit"] - gl["Credit"]

    out_path = Path("data/transformed/workday_gl_workbook.csv")
    gl.to_csv(out_path, index=False)
    print(f"Transformed GL data saved to {out_path}")

if __name__ == "__main__":
    transform_gl_data()
