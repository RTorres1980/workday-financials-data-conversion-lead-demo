# Weekly Status Template

- Progress Summary
- Risks and Issues
- Next Steps